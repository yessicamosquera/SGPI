﻿using Microsoft.AspNetCore.Mvc;

namespace SGPI.Controllers
{
    public class AdministradorController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        //Agrego el de olvidar contraseña
        public IActionResult OlvidarContrasena()
        {
            return View();
        }
        //Agrego el de crear usuario
        public IActionResult CrearUsuario()
        {
            return View();
        }
        //Editar usuario
        public IActionResult EditarUsuario()
        {
            return View();
        }

        //Buscar Usuario
        public IActionResult BuscarUsuario()

        {
            return View();
        }
            
    }
}
